package trabalhoestruduradedados;

   class PilhaCompra {
    private class Nodo {
        Compra compra;
        Nodo proximo;

        public Nodo(Compra compra) {
            this.compra = compra;
            this.proximo = null;
        }
    }

    private Nodo topo;

    public PilhaCompra() {
        this.topo = null;
    }

    public void empilhar(Compra compra) {
        Nodo novoNodo = new Nodo(compra);
        novoNodo.proximo = topo;
        topo = novoNodo;
    }

    public Compra desempilhar() {
        if (topo == null) {
            System.out.println("Pilha vazia.");
            return null;
        }
        Compra compraRemovida = topo.compra;
        topo = topo.proximo;
        return compraRemovida;
    }

    public Compra topo() {
        if (topo == null) {
            System.out.println("Pilha vazia.");
            return null;
        }
        return topo.compra;
    }

    public boolean pilhaVazia() {
        return topo == null;
    }
}
