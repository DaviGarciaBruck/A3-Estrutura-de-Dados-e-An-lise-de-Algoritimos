package trabalhoestruduradedados;

public class SistemaDeEstoque {
    public static void main(String[] args) {
        PilhaCompra pilha = new PilhaCompra();
        
        // Registrando uma compra de "Mel"
        Compra compra1 = new Compra("Mel", 10.0, 15.0, 100, 100);
        pilha.empilhar(compra1);

        // Registrando uma nova compra de "Mel", atualizando preço e estoque
        Compra compra2 = new Compra("Mel", 11.0, 16.0, 150, 150);
        pilha.empilhar(compra2);
        
        // Consultando a última compra
        Compra ultimaCompra = pilha.topo();
        System.out.println("Última compra registrada: " + ultimaCompra);

        // Simulando venda de alguns itens e ajustando o estoque
        ultimaCompra.quantidadeEmEstoque -= 10; // Vendemos 10 unidades
        System.out.println("Estoque atualizado após venda: " + ultimaCompra.quantidadeEmEstoque);
    }
}

