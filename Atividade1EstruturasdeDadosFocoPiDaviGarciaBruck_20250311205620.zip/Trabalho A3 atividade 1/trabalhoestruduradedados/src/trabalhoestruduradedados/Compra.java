package trabalhoestruduradedados;

    import java.util.Date;

public class Compra {

    Date dataCompra;
    String produto;
    double valorCompra;
    double valorVenda;
    int quantidadeComprada;
    int quantidadeEmEstoque;

    public Compra(String produto, double valorCompra, double valorVenda, int quantidadeComprada, int quantidadeEmEstoque) {
        this.dataCompra = new Date(); // A data é atribuída automaticamente no momento da compra
        this.produto = produto;
        this.valorCompra = valorCompra;
        this.valorVenda = valorVenda;
        this.quantidadeComprada = quantidadeComprada;
        this.quantidadeEmEstoque = quantidadeEmEstoque;
    }

    @Override
    public String toString() {
        return "Compra{" +
                "produto='" + produto + '\'' +
                ", valorCompra=" + valorCompra +
                ", valorVenda=" + valorVenda +
                ", quantidadeComprada=" + quantidadeComprada +
                ", quantidadeEmEstoque=" + quantidadeEmEstoque +
                '}';
    }
}   